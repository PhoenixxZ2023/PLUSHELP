# SSH-PLUS ⚡


# TELEGRAM @TURBONETVPN2023

✅ WEBSOCKET SECURITY

✅ V2RAY  FUNCIONANDO

✅ CHECKUSER CONECTA4G

✅ CHECKUSER GL TUNNEL  MOD

✅ CHECKUSER ANYVPN MOD

✅ BADVPN PRO

✅ MENU APACHE

✅ MOSTRADOR DE CONSUMO

✅ TCPTWEAKER

✅ MEMÓRIA SWAP

✅ FIREWALL ORACLE

## :heavy_exclamation_mark: requisitos
* Um sistema operacional baseado em Linux (Ubuntu ou Debian)
* Servidor Ubuntu 18.04 x86_64 / Servidor Ubuntu 20.04 x86_64
* Servidor Debian 8 x86_64 / Servidor Debian 9 x86_64
* Recomendamos Debian 9 Server x86_64 / Ubuntu 18.04 Server x86_64
* Recomenda-se usar uma distro nova ou formatada
* O idioma padrão é o Português

# SSH PLUS 2023 INSTALAÇÃO

# Como Instalar!

# OPÇÃO 1
````
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/PhoenixxZ2023/PLUS/main/ssh-plus)
````

# OPÇÃO 2
```
bash <(wget -qO- raw.githubusercontent.com/PhoenixxZ2023/PLUS/main/ssh-plus)

```

# Instalar Direto e Máquinas 64!

````
wget https://raw.githubusercontent.com/PhoenixxZ2023/PLUS/main/script/64/ssh-plus ; chmod +x Plus ; ./Plus
````


# BOT ZAP 😝 ![icons8-whatsapp-48](https://user-images.githubusercontent.com/101994539/224822427-60c31ec9-ad6e-4e94-90f6-34f65aedb080.png)


```
wget https://www.dropbox.com/s/wpi8v0i5slfm0uf/TBotPlus_Cliente_2008_v1.0.9.zip; unzip TBotPlus_Cliente_*.zip && cd TBotPlus; chmod +x TerminusBot.sh && ./TerminusBot.sh && wget -qO- https://raw.githubusercontent.com/creationix/nvm/v0.34.0/install.sh | bash && source ~/.profile && nvm install 16 && terminus
````

# PARA TER ACESSO AS OPÇÕES  OU MENU DO BOT E SO DIGITAR:

````
terminus
````
